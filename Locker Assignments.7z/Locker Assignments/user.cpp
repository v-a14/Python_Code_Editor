#include<iostream>
#include<vector>
#include<set>
#include<map>
#include<unordered_map>

using namespace std;

unordered_map<int, int>user2lock; // gives index of locker allocated to a user
set<int>filled; // filled locker index to be used while dellocating locker
set<pair<int, int>> freelockers;  //size, begin
int n, cnt;

void init(int N) {
	n = N;
	cnt = N;
	user2lock.clear();
	filled.clear();
	freelockers.clear();
	
	freelockers.insert({ n,1 });
	return;
}

int arrive(int mId) {
	cnt--;
	auto it = freelockers.end();
	it--;
	pair<int, int> p1 = *it;

	auto itr = freelockers.lower_bound({ p1.first, 1 });
	pair<int, int>p = *itr;
	int s = p.second;
	int e = p.first + p.second - 1;
	freelockers.erase(p);

	if (s == 1) {
		
		user2lock[mId] = 1;
		freelockers.insert({p.first-1, 2});
		filled.insert(1);
		return 1;
	}
	else if (e == n) {
		user2lock[mId] = n;
		freelockers.insert({ p.first-1, s });
		filled.insert(n);
		return n;
	}
	else {
		int mid = (s + e) / 2;
		user2lock[mId] = mid;
		filled.insert(mid);
		freelockers.insert({ mid-s, s });
		freelockers.insert({ e-mid, mid+1 });
		return mid;
	}

	return 0;
}

int leave(int mId) {
	cnt++;
	int pos = user2lock[mId];
	auto st = filled.lower_bound(pos);
	auto en = filled.upper_bound(pos);
	
	if (st == filled.begin() && en == filled.end()) {
		freelockers.clear();
		freelockers.insert({ n,1 });
	}
	else if (st != filled.begin() && en == filled.end()) {
		st--;
		int start = *st;
		freelockers.erase({ pos - start - 1, start + 1 });
		freelockers.erase({ n - pos, pos + 1 });
		freelockers.insert({ n - start, start + 1 });
	}

	//case3: not at left only at right
	else if (st == filled.begin() && en != filled.end())
	{
		int end = *en;
		freelockers.erase({ pos - 1, 1 });
		freelockers.erase({ end - pos - 1, pos + 1 });
		freelockers.insert({ end - 1, 1 });
	}

	//case4: both at left as well as at right
	else
	{
		st--;
		int start = *st;
		int end = *en;

		freelockers.erase({ pos - start - 1, start + 1 });
		freelockers.erase({ end - pos - 1, pos + 1 });
		freelockers.insert({ end - start - 1, start + 1 });
	}


	filled.erase(pos);
	user2lock.erase(mId);

	return cnt;
}